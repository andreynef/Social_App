A Pen created at CodePen.io. You can find this one at http://codepen.io/colinhorn/pen/zdNMVy.

 Pure CSS animated loader. Originally wanted to re-create the GIT Kraken "Loading Repo" animation but, it became this instead.