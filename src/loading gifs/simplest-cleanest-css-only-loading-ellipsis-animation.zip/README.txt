A Pen created at CodePen.io. You can find this one at http://codepen.io/ines/pen/WOVXxZ.

 A very simple animation using no extra HTML markup and only one pseudo-element with text shadows, that perfectly mimic the dots and adapt across fonts, sizes and styles.

Most implementations of this animation either rely on wrapping the three dots in span elements (which is ugly and inconvenient), or use the ellipsis character as the :after pseudo-element and decrease and increase its width, which can  produce unpredictable results across font families and styles.